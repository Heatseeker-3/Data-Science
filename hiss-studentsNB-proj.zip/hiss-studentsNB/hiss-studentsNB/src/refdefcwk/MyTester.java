package refdefcwk;

/**
 * For possible solutions to Task 5 look at Task 1 & Task 4 testing
 *
 */
public class MyTester
{
//      public static void doTest1()
//      {
//          // Task 1 testing
//          HISS gp = new Manager("Olenka",1000);
//          System.out.println("Display Jobs & Staff for Hire");
//          System.out.println(gp.getAllJobs());
//          System.out.println("*********************************");
//          System.out.println(gp.getAllAvailableStaff());
//          System.out.println("*********************************");
//          System.out.println(gp.toString());
//          System.out.println("*********************************");
//          System.out.println("Account:" + gp.getAccount());
//          System.out.println("*********************************");
//
//      }

    public static void hiringStaff()
    {
        HISS gp = new Manager("Olenka",1000, "jobs.txt"); // Use constructor with jobs.txt
        System.out.println("\n--- Test: Hiring Staff ---");
        System.out.println("Hire Staff");
        // These names must match the names in Manager.setupStaff()
        // Assuming your setupStaff in Manager has Alan, Gita, Hela (replace with actual names if different)
        // From your previous Manager.java, staff names are: Amir, Firat, Jaga, Bela, Ceri, Hui, Dana, Eli, Gani.
        // Let's adjust the names in this test to match those.
        System.out.println(gp.hireStaff("Bela")); // Consultant, retainer 100
        System.out.println(gp.hireStaff("Gani")); // Installer, retainer 200
        System.out.println(gp.hireStaff("Amir")); // Planner, retainer 300
        System.out.println("\n******Are Bela, Gani & Amir Hired ??");
        System.out.println(gp.toString());
        System.out.println("*********************************");
        System.out.println("\n*****Bela, Gani & Amir should not be on the available list");
        System.out.println(gp.getAllAvailableStaff());
        System.out.println("*********************************");
        //Hire Staff - but no money
        System.out.println("\n*****Hire another - no money. Firat not hired (needs 300)");
        System.out.println("Current Account (after 100+200+300=600): " + gp.getAccount() + " (should be 400)");
        System.out.println(gp.hireStaff("Firat")); // Try to hire Firat (retainer 300)
        System.out.println(gp.toString());
        System.out.println("*********************************");
    }

    public static void engDoingSoftware()
    {
        //Not eligible - Renamed "Bob" to a valid staff member based on your Manager class
        // Let's use "Dana" (Installer, not trained)
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Dana"); // Dana (Installer, not trained)
        System.out.println("\n--- Test: Installer (Dana) doing Maintenance (Job 101) - not trained ---");
        System.out.println("Account should be 800 (1000 - 200 retainer for Dana)");
        System.out.println("Account is " + gp.getAccount());
        // Job 101 is Maintenance, Dana is Installer but not trained, so should fail (penalty)
        System.out.println("Result is: " +  gp.doJob(101)); // Job 101 is Maintenance, penalty 150
        System.out.println("Account should be 650 (800 - 150 penalty)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void engDoingHwarNoExper()
    {
        //eligible but inexperienced - Renamed "Bob" to valid staff
        // Let's use "Gani" (Installer, trained, Exp 2) and Job 104 (Installation, Diff 7)
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Gani"); // Gani (Installer, trained, Exp 2)
        System.out.println("\n--- Test: Installer (Gani) doing Installation (Job 104) - inexperienced ---");
        System.out.println("Account should be 800 (1000 - 200 retainer for Gani)");
        System.out.println("Account is " + gp.getAccount());
        // Job 104 is Installation, difficulty 7. Gani has experience 2. Should fail due to inexperience (penalty)
        System.out.println("Result is: " +  gp.doJob(104)); // Job 104 penalty 350
        System.out.println("Account should be 450 (800 - 350 penalty)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void engDoingHwarWithExper()
    {
        //eligible with experience - job done - Renamed "Ceri" to valid staff
        // Let's use "Eli" (Installer, trained, Exp 7) and Job 104 (Installation, Diff 7)
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Eli"); // Eli (Installer, trained, Exp 7)
        System.out.println("\n--- Test: Installer (Eli) doing Installation (Job 104) - experienced ---");
        System.out.println("Account should be 800 (1000 - 200 retainer for Eli)");
        System.out.println("Account is " + gp.getAccount());
        // Job 104 is Installation, 15 hours, penalty 350. Eli hourly rate 20. Difficulty 7. Eli experience 7.
        System.out.println("Result is: " +  gp.doJob(104)); // Job 104 cost: 15 hours * 20 = 300
        System.out.println("Account should be 1100 (800 + 300 job cost)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void programmerDoingHardware()
    {
        //Not eligible - Renamed "Gita" to a valid staff (e.g., Planner Firat)
        // Planners can only do DESIGN. Trying to do MAINTENANCE (Job 101)
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Firat"); // Firat (Planner, Exp 6)
        System.out.println("\n--- Test: Planner (Firat) doing Maintenance (Job 101) - not eligible ---");
        System.out.println("Account should be 700 (1000 - 300 retainer for Firat)");
        System.out.println("Account is " + gp.getAccount());
        // Job 101 is Maintenance, penalty 150. Firat cannot do Maintenance.
        System.out.println("Result is: " +  gp.doJob(101));
        System.out.println("Account should be 550 (700 - 150 penalty)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void programmerDoingSoftwareNoExp()
    {
        //eligible but inexperienced - Renamed "Gita" to valid staff (e.g., Planner Amir)
        // Planner Amir (Exp 2) doing Design (Job 100, Diff 3) - should be inexperienced
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Amir"); // Amir (Planner, Exp 2)
        System.out.println("\n--- Test: Planner (Amir) doing Design (Job 100) - inexperienced ---");
        System.out.println("Account should be 700 (1000 - 300 retainer for Amir)");
        System.out.println("Account is " + gp.getAccount());
        // Job 100 is Design, difficulty 3. Amir has experience 2. Should fail (penalty).
        System.out.println("Result is: " +  gp.doJob(100)); // Job 100 penalty 200
        System.out.println("Account should be 500 (700 - 200 penalty)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void programmerDoingSoftwareWithExp()
    {
        // Eligible and experienced - Renamed "Ela" to valid staff (e.g., Planner Firat)
        // Planner Firat (Exp 6) doing Design (Job 100, Diff 3) - experienced
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Firat"); // Firat (Planner, Exp 6)
        System.out.println("\n--- Test: Planner (Firat) doing Design (Job 100) - experienced ---");
        System.out.println("Account should be 700 (1000 - 300 retainer for Firat)");
        System.out.println("Account is " + gp.getAccount());
        // Job 100 is Design, 10 hours, penalty 200. Firat hourly rate 90. Difficulty 3. Firat experience 6.
        System.out.println("Result is: " +  gp.doJob(100)); // Job 100 cost: 10 hours * 90 = 900
        System.out.println("Account should be 1600 (700 + 900 job cost)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void programmerDoingDesignWithExp()
    {
        // Not eligible - This test seems redundant with programmerDoingSoftwareWithExp
        // as Planners only do Design. Re-purpose or remove.
        // Let's use it to test a Planner (Firat) doing another Design job
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Firat"); // Firat (Planner, Exp 6)
        System.out.println("\n--- Test: Planner (Firat) doing another Design (Job 103) - experienced ---");
        System.out.println("Account should be 700 (1000 - 300 retainer for Firat)");
        System.out.println("Account is " + gp.getAccount());
        // Job 103 is Design, 25 hours, penalty 250. Firat hourly rate 90. Difficulty 9. Firat experience 6.
        System.out.println("Result is: " +  gp.doJob(103)); // Job 103 should fail due to inexperience (Exp 6 vs Diff 9)
        System.out.println("Account should be 450 (700 - 250 penalty)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void desDoingSoftwareWithProgNoExp()
    {
        // Eligible but inexperienced - Renamed "Ian" to valid staff (e.g., Consultant Bela)
        // Consultant Bela (Exp 2, not CORGI) doing Installation (Job 102, Diff 3)
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Bela"); // Bela (Consultant, Exp 2, retainer 100)
        System.out.println("\n--- Test: Consultant (Bela) doing Installation (Job 102) - experienced (2>=3 is false, so inexperienced) ---");
        System.out.println("Account should be 900 (1000 - 100 retainer for Bela)");
        System.out.println("Account is " + gp.getAccount());
        // Job 102 is Installation, difficulty 3. Bela has experience 2. Should fail (penalty).
        System.out.println("Result is: " +  gp.doJob(102)); // Job 102 penalty 100
        System.out.println("Account should be 800 (900 - 100 penalty)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void desDoingSoftwareWithProgWithExp()
    {
        // Eligible and experienced - Renamed "Ian" to valid staff (e.g., Consultant Ceri)
        // Consultant Ceri (Exp 4, CORGI) doing Installation (Job 102, Diff 3) - experienced
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Ceri"); // Ceri (Consultant, Exp 4, retainer 250)
        System.out.println("\n--- Test: Consultant (Ceri) doing Installation (Job 102) - experienced ---");
        System.out.println("Account should be 750 (1000 - 250 retainer for Ceri)");
        System.out.println("Account is " + gp.getAccount());
        // Job 102 is Installation, 30 hours, penalty 100. Ceri hourly rate 40. Difficulty 3. Ceri experience 4.
        System.out.println("Result is: " +  gp.doJob(102)); // Job 102 cost: 30 hours * 40 = 1200
        System.out.println("Account should be 1950 (750 + 1200 job cost)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void desDoingDesignWithProgWithExp()
    {
        // Not eligible - This test name is confusing (des doing design with prog)
        // Let's use Consultant Hui (Exp 8, CORGI) doing Design (Job 103, Diff 9)
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        gp.hireStaff("Hui"); // Hui (Consultant, Exp 8, retainer 450)
        System.out.println("\n--- Test: Consultant (Hui) doing Design (Job 103) - inexperienced (8 < 9) ---");
        System.out.println("Account should be 550 (1000 - 450 retainer for Hui)");
        System.out.println("Account is " + gp.getAccount());
        // Job 103 is Design, difficulty 9. Hui has experience 8. Should fail (penalty).
        System.out.println("Result is: " +  gp.doJob(103)); // Job 103 penalty 250
        System.out.println("Account should be 300 (550 - 250 penalty)");
        System.out.println("Account is " + gp.getAccount());
    }

    public static void doingJobsInTeam1()
    {
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        // Hire Staff
        System.out.println("\n--- Test: Doing Jobs in Team 1 ---");
        System.out.println("Hire Staff:");
        System.out.println(gp.hireStaff("Eli")); // Installer, Exp 7, trained. Retainer 200. Account: 800
        System.out.println(gp.hireStaff("Amir")); // Planner, Exp 2. Retainer 300. Account: 500
        System.out.println(gp.hireStaff("Ceri")); // Consultant, Exp 4, CORGI. Retainer 250. Account: 250

        //Do Job
        System.out.println("\n*****Do Job**********");
        System.out.println("\n*****After Hiring account should be 250");
        System.out.println("Account = " + gp.getAccount());

        // Eli (Installer) doing Job 101 (Maintenance, 20 hrs, Diff 3, Penalty 150). Eli is trained (can do), Exp 7 >= Diff 3.
        // Cost: 20 * 20 (Eli's hourly) = 400. Account: 250 + 400 = 650. Eli on leave.
        System.out.println("\n*****Job done - Account will be 650 (Eli for Job 101)");
        System.out.println(gp.doJob(101));

        // Amir (Planner) doing Job 100 (Design, 10 hrs, Diff 3, Penalty 200). Amir can do Design, Exp 2 < Diff 3. Fails.
        // Penalty: 200. Account: 650 - 200 = 450. Amir still WORKING (or ONLEAVE if Manager.doJob changes state regardless of success)
        System.out.println("\n*****Job lost on skill level - Account will be 450 (Amir for Job 100)");
        System.out.println(gp.doJob(100)); // Will be done by Ceri (Consultant) if Ceri is still working
        // Re-checking the Manager.doJob logic: "finds a staff member in the team who can do the job".
        // It picks the *first* available working staff.
        // If Eli is on leave, and Amir failed due to inexperience, Ceri is still WORKING and can do Job 100 (Design).
        // Let's assume Ceri does it. Ceri (hourly 40) for Job 100 (10 hrs). Cost 400. Account: 450 + 400 = 850. Ceri on leave.
        // If Ceri doesn't do it, then it's "no staff available".
        // Based on the code, if Amir fails due to inexperience, the job is not completed by *him*.
        // The problem description says "Job not completed due to staff inexperience" -> deduct penalty.
        // It doesn't say "try next staff". So if Amir fails, the job fails.
        // Let's stick to the previous expected output: 450.

        // Job 104 (Installation, penalty 350). Eli and Ceri are on leave. Amir failed last job, still WORKING.
        // Amir cannot do Installation. So, no staff available. Penalty.
        // Account: 450 - 350 = 100.
        System.out.println("\n*****Job lost as no Staff - Account will be 100 (Job 104)");
        System.out.println(gp.doJob(104));

    }

    public static void doingJobsInTeam2()
    {
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        // Main Functionality
        // Hire Staff
        System.out.println("\n--- Test: Doing Jobs in Team 2 (Repeated Job) ---");
        System.out.println("Hire Staff");
        System.out.println(gp.hireStaff("Eli"));   // Installer, Exp 7, trained. Retainer 200. Account: 800
        System.out.println(gp.hireStaff("Amir"));  // Planner, Exp 2. Retainer 300. Account: 500
        System.out.println(gp.hireStaff("Ceri"));  // Consultant, Exp 4, CORGI. Retainer 250. Account: 250

        //Do Job
        System.out.println("\n*****Do Job**********");
        System.out.println("\n*****After Hiring account should be 250");
        System.out.println("Account = " + gp.getAccount());

        // Eli (Installer) doing Job 101 (Maintenance). Cost: 20 * 20 = 400. Account: 250 + 400 = 650. Eli on leave.
        System.out.println("\n*****Job done - Account will be 650 (Eli for Job 101)");
        System.out.println(gp.doJob(101));

        // Amir (Planner) doing Job 100 (Design). Fails due to inexperience (Exp 2 vs Diff 3). Penalty 200. Account: 650 - 200 = 450.
        System.out.println("\n*****Job lost on skill level - Account will be 450 (Amir for Job 100)");
        System.out.println(gp.doJob(100));

        // Try Job 101 again (Maintenance). Eli is on leave. Amir is WORKING but can't do Maintenance. Ceri is WORKING, can do Maintenance.
        // Ceri (hourly 40) for Job 101 (20 hrs). Cost: 20 * 40 = 800. Account: 450 + 800 = 1250. Ceri on leave.
        System.out.println("\n*****Job 101 done again - Account will be 1250 (Ceri for Job 101)");
        System.out.println(gp.doJob(101));

    }

    public static void onHoliday()
    {
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        // Hire Staff
        System.out.println("\n--- Test: Staff On Holiday ---");
        System.out.println("Hire Staff");
        System.out.println(gp.hireStaff("Eli")); // Eli (Installer, trained, Exp 7). Retainer 200. Account: 800

        //Do Job
        System.out.println("\n*****Do Job**********");
        System.out.println("\n*****After Hiring account should be 800");
        System.out.println("Account = " + gp.getAccount());

        // Job 101 (Maintenance). Eli does it. Cost 400. Account: 800 + 400 = 1200. Eli on leave.
        System.out.println("\n*****Job done - Account will be 1200 (Eli for Job 101)");
        System.out.println(gp.doJob(101));

        // Try Job 101 again. Eli is on leave. No other staff. Penalty 150. Account: 1200 - 150 = 1050.
        System.out.println("\n*****Eli on holiday - not available - Account 1050");
        System.out.println(gp.doJob(101)); // Should be 1050 (1200-150)

        System.out.println("\n*****Eli returns- job done - account = 1450"); // 1050 + 400
        gp.staffRejoinTeam("Eli"); // Eli rejoins
        // Try Job 101 again. Eli is working. Cost 400. Account: 1050 + 400 = 1450. Eli on leave.
        System.out.println(gp.doJob(101));
    }

    public static void gettingOverdrawn()
    {
        HISS gp = new Manager("Olenka",1000, "jobs.txt");
        // Hire Staff
        System.out.println("\n--- Test: Getting Overdrawn ---");
        System.out.println("Hire Staff");
        System.out.println(gp.hireStaff("Eli"));   // Eli (Installer). Retainer 200. Account: 800
        System.out.println(gp.hireStaff("Amir"));  // Amir (Planner). Retainer 300. Account: 500
        System.out.println(gp.hireStaff("Ceri"));  // Ceri (Consultant). Retainer 250. Account: 250

        //Do Job
        System.out.println("\n*****Do Job**********");
        System.out.println("\n*****After Hiring account should be 250");
        System.out.println("Account = " + gp.getAccount());

        // Job 103 (Design, Diff 9, Penalty 250). Eli can't do. Amir (Exp 2 < Diff 9) fails. Ceri (Exp 4 < Diff 9) fails.
        // All staff in team are WORKING. Eli and Amir are working but can't do design type. Ceri is working but fails on experience.
        // The manager.doJob will pick Ceri first (as Consultant can do Design). Ceri has Exp 4, Job 103 has Diff 9.
        // So Ceri is inexperienced. Penalty 250 deducted.
        // Account: 250 - 250 = 0.
        System.out.println("\n*****Job not done - Account will be 0 (Ceri fails on experience for Job 103)");
        System.out.println(gp.doJob(103)); // Expect 0 and overdrawn status.

        // Try another job (104, Installation, Penalty 350).
        // Eli is working (Exp 7 >= Diff 7). Eli does job. Cost (15 hrs * 20) = 300.
        // Account: 0 + 300 = 300.
        System.out.println("\n*****Job 104 done (Eli) - Account will be 300");
        System.out.println(gp.doJob(104)); // Account goes to 300

        // Now, let's try to get overdrawn by hiring another staff (if Manager allows it)
        // Or by failing another job.
        // Let's hire another staff first (requires 300).
        System.out.println("\n*****Trying to hire Firat (Retainer 300)");
        System.out.println(gp.hireStaff("Firat")); // Account was 300, now 0.

        // Now, if we do a job that fails (e.g., Job 105 - Maintenance, Penalty 300)
        // Eli is on leave. Amir is working, cannot do Maintenance. Ceri is working, can do Maintenance.
        // Ceri has Exp 4. Job 105 Diff 8. Ceri fails on experience. Penalty 300.
        // Account: 0 - 300 = -300.
        System.out.println("\n*****Job 105 fails, Account will be -300 and overdrawn");
        System.out.println(gp.doJob(105)); // Account goes to -300

        System.out.println("\nProject state after being overdrawn:");
        System.out.println(gp.toString());
        System.out.println("Is overdrawn? " + gp.isOverdrawn()); // Should be true if no staff on leave
    }


    // The main method to run all tests
    public static void main(String[] args) {
        System.out.println("--- Running MyTester Scenarios ---");

        // Uncomment the tests you want to run.
        // You might want to run them one by one initially to check outputs.

        // doTest1(); // Uncomment if you want to test initial setup (assuming Manager constructor without jobs.txt for this)

        hiringStaff();
        System.out.println("\n-----------------------------------\n");

        engDoingSoftware();
        System.out.println("\n-----------------------------------\n");

        engDoingHwarNoExper();
        System.out.println("\n-----------------------------------\n");

        engDoingHwarWithExper();
        System.out.println("\n-----------------------------------\n");

        programmerDoingHardware();
        System.out.println("\n-----------------------------------\n");

        programmerDoingSoftwareNoExp();
        System.out.println("\n-----------------------------------\n");

        programmerDoingSoftwareWithExp();
        System.out.println("\n-----------------------------------\n");

        programmerDoingDesignWithExp(); // Adjusting this test to fail due to inexperience
        System.out.println("\n-----------------------------------\n");

        desDoingSoftwareWithProgNoExp();
        System.out.println("\n-----------------------------------\n");

        desDoingSoftwareWithProgWithExp();
        System.out.println("\n-----------------------------------\n");

        desDoingDesignWithProgWithExp(); // Adjusting this test to fail due to inexperience
        System.out.println("\n-----------------------------------\n");

        doingJobsInTeam1();
        System.out.println("\n-----------------------------------\n");

        doingJobsInTeam2();
        System.out.println("\n-----------------------------------\n");

        onHoliday();
        System.out.println("\n-----------------------------------\n");

        gettingOverdrawn();
        System.out.println("\n-----------------------------------\n");


        System.out.println("--- All MyTester Scenarios Completed ---");
    }
}