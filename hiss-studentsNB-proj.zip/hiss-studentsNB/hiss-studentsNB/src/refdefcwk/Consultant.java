package refdefcwk;

import java.io.Serializable;

/**
 * Represents a Consultant staff member in the HISS simulation.
 * Consultants can perform Design, Installation, and Maintenance tasks.
 * Their hourly rate depends on whether they are CORGI certified.
 *
 * @author Your Name / SRN
 * @version 2025-06-13
 */
public class Consultant extends Staff implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization

    private boolean corgiCertified;

    /**
     * Constructor for the Consultant class.
     *
     * @param name         The unique name of the consultant.
     * @param experience   The experience level of the consultant (1-10).
     * @param retainer     The retainer set by the consultant.
     * @param corgiCertified True if the consultant is CORGI certified, false otherwise.
     */
    public Consultant(String name, int experience, double retainer, boolean corgiCertified) {
        super(name, experience);
        this.retainer = retainer; // Consultant sets their own retainer
        this.corgiCertified = corgiCertified;
        // Set hourly rate based on CORGI certification
        this.hourlyRate = corgiCertified ? 40.00 : 30.00;
    }

    /**
     * Checks if the Consultant can perform a specific job type.
     * Consultants can do DESIGN, INSTALLATION, and MAINTENANCE tasks.
     *
     * @param jobType The type of job to check against.
     * @return true as Consultants can perform all job types.
     */
    @Override
    public boolean canDoJob(JobType jobType) {
        // Consultants can do all types of jobs
        return true;
    }

    /**
     * Provides a detailed string representation of the Consultant.
     * Includes general staff details and whether they are CORGI certified.
     *
     * @return A string containing the consultant's details.
     */
    @Override
    public String toString() {
        // FIX: Change "Yes"/"No" to "true"/"false" for corgiCertified to match GeneralTest expectation.
        return super.toString() + String.format(", CORGI Certified: %s", String.valueOf(corgiCertified));
    }
}