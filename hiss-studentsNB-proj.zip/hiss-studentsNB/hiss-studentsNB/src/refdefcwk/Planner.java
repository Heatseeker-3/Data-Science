package refdefcwk;

import java.io.Serializable;

/**
 * Represents a Planner staff member in the HISS simulation.
 * Planners can only perform Design tasks. Their hourly rate is calculated
 * based on their experience.
 *

 */
public class Planner extends Staff implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization

    private String fixtureMake; // Make of fixture they specialise in

    /**
     * Constructor for the Planner class.
     *
     * @param name        The unique name of the planner.
     * @param experience  The experience level of the planner (1-10).
     * @param fixtureMake The make of fixture the planner specializes in.
     */
    public Planner(String name, int experience, String fixtureMake) {
        super(name, experience);
        this.fixtureMake = fixtureMake;
        this.retainer = 300.00; // Fixed retainer for Planners
        // Hourly rate calculated by multiplying experience by 15
        this.hourlyRate = experience * 15.00;
    }

    /**
     * Checks if the Planner can perform a specific job type.
     * Planners can only do DESIGN tasks.
     *
     * @param jobType The type of job to check against.
     * @return true if the job type is DESIGN, false otherwise.
     */
    @Override
    public boolean canDoJob(JobType jobType) {
        return jobType == JobType.DESIGN;
    }

    /**
     * Provides a detailed string representation of the Planner.
     * Includes general staff details and their specialized fixture make.
     *
     * @return A string containing the planner's details.
     */
    @Override
    public String toString() {
        return super.toString() + String.format(", Specialises in: %s", fixtureMake);
    }
}