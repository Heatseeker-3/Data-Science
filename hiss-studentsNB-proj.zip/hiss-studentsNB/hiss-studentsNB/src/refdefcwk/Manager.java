package refdefcwk;

import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * This class specifies the behaviour expected from the HISS system
 * as required for 5COM2007 Referred/Deferred Cwk - June 2025
 * specified in the HISS interface.
 *
 */
public class Manager implements HISS, Serializable {

    private static final long serialVersionUID = 1L; // For serialization

    private String name;
    private double account;
    private Map<String, Staff> allStaff; // Stores all staff members (available, working, on leave) by name
    private Map<String, Staff> teamStaff; // Stores staff currently in the project team (working or on leave) by name
    private Map<Integer, Job> allJobs; // Stores all jobs by job number
    private int nextJobNo = 1000; // CORRECTED: Initialize a counter for sequential job numbers, start from 100 as per MyTester


    //**************** HISS **************************

    /**
     * Constructor requires the name of the trainee manager and initial budget.
     * Staff and jobs are also set up, with all staff set to "available" for hire.
     *
     * @param manager The name of the trainee manager running the simulation.
     * @param budget  The initial budget allocated to the project account.
     */
    public Manager(String manager, double budget) {
        System.out.println("DEBUG: Manager constructor (no file) called for " + manager);
        this.name = manager;
        this.account = budget;
        this.allStaff = new HashMap<>();
        this.teamStaff = new HashMap<>();
        this.allJobs = new HashMap<>();
        setupStaff();
        setupJobs(); // Call this to load default jobs if not reading from file
        System.out.println("DEBUG: Manager (no file) constructor finished. allJobs size: " + allJobs.size());
    }

    /**
     * Constructor requires the name of the trainee manager, initial budget
     * and name of jobs file. Staff are also set up, with all staff set to
     * "available" for hire. Jobs are "read from a file".
     *
     * @param manager The name of the trainee manager running the simulation.
     * @param budget  The initial budget allocated to the project account.
     * @param jobfile The name of the jobs file.
     */
    public Manager(String manager, double budget, String jobfile) {
        System.out.println("DEBUG: Manager constructor (with file) called for " + manager + " loading " + jobfile);
        this.name = manager;
        this.account = budget;
        this.allStaff = new HashMap<>();
        this.teamStaff = new HashMap<>();
        this.allJobs = new HashMap<>();
        setupStaff();
        readJobs(jobfile); // Read jobs from the specified file
        System.out.println("DEBUG: Manager (with file) constructor finished. allJobs size: " + allJobs.size());
    }

    /**
     * Returns a String representation of the state of the project,
     * including the name of the manager, state of the project account,
     * whether overdrawn or not, and the staff currently in the
     * team (or, "No staff" if team is empty).
     *
     * @return a String representation of the state of the project.
     **/
    @Override
    public String toString() {
        String s = "\nManager: " + name;
        s += String.format("\nProject Account: £%.2f", account);
        if (isOverdrawn()) {
            s += " (OVERDRAWN)";
        } else {
            s += " (Not Overdrawn)";
        }
        s += "\n--- Team Members ---";
        if (teamStaff.isEmpty()) {
            s += "\nNo staff hired.";
        } else {
            for (Staff staff : teamStaff.values()) {
                s += "\n" + staff.toString();
            }
        }
        return s;
    }

    /**
     * Returns the amount of money in the account.
     *
     * @returns the amount of money in the account.
     */
    @Override
    public double getAccount() {
        return account;
    }

    /**
     * Returns true if project account <=0 and the team has no staff
     * who can leave (i.e., no one on leave who can rejoin).
     *
     * @returns true if project account <=0 and the team has no staff
     * who can leave.
     */
    @Override
    public boolean isOverdrawn() {
        if (account > 0) {
            return false;
        }
        // Check if there's any staff on leave who could potentially rejoin to alleviate overdrawn status
        for (Staff staff : teamStaff.values()) {
            if (staff.getState() == StaffState.ONLEAVE) {
                return false; // There's someone on leave, so not truly overdrawn
            }
        }
        return true; // Account is <= 0 and no staff on leave
    }

    //********************** All Jobs*************************

    /**
     * Returns true if the number represents a job.
     *
     * @param num is the reference number of the job.
     * @returns true if the reference number represents a job.
     **/
    @Override
    public boolean isJob(int num) {
        return allJobs.containsKey(num);
    }


    /**
     * Returns a String representation of all jobs.
     *
     * @return returns a String representation of all jobs.
     **/
    @Override
    public String getAllJobs() {
        String s = "\n************ All Jobs ************\n";
        if (allJobs.isEmpty()) {
            s += "No jobs available.";
        } else {
            // Sort jobs by job number for consistent display
            List<Job> sortedJobs = new ArrayList<>(allJobs.values());
            sortedJobs.sort(Comparator.comparingInt(Job::getJobNo));
            for (Job job : sortedJobs) {
                s += job.toString() + "\n";
            }
        }
        return s;
    }

    /**
     * Returns a String with information about specified job.
     *
     * @param no - number of the specified job.
     * @return returns a String representation of the specified job, or "No such job".
     **/
    @Override
    public String getJob(int no) {
        Job job = allJobs.get(no);
        if (job != null) {
            return job.toString();
        }
        return "No such job: " + no;
    }

    //*********************** All Staff *************************

    /**
     * Returns details of a staff member with the given name,
     * (staff may be in or out of the team).
     *
     * @param name the name of the required staff member.
     * @return details of a staff member with the name specified
     * in the parameter. Returns "No such staff" if not found.
     **/
    @Override
    public String getStaff(String name) {
        Staff staff = allStaff.get(name);
        if (staff != null) {
            return staff.toString();
        }
        return "\nNo such staff: " + name;
    }

    /**
     * Returns a String representation of the details of all staff
     * available for hire.
     *
     * @return a String representation of the details of all staff
     * available for hire.
     **/
    @Override
    public String getAllAvailableStaff() {
        String s = "************ Staff for Hire********\n";
        boolean found = false;
        // Sort available staff by name for consistent display
        List<Staff> sortedStaff = new ArrayList<>(allStaff.values());
        sortedStaff.sort(Comparator.comparing(Staff::getName));

        for (Staff staff : sortedStaff) {
            if (staff.getState() == StaffState.AVAILABLE) {
                s += staff.toString() + "\n";
                found = true;
            }
        }
        if (!found) {
            s += "No staff currently available for hire.\n";
        }
        return s;
    }


    // ***************** Team Staff ************************

    /**
     * Allows staff to be added to the team, if there is enough
     * money in the account for the retainer.The hired staff member's
     * state is set to "working" and their retainer is deducted from
     * the project account. Return the result of the hire; all messages
     * should include the staff name and state of the project account.
     *
     * @param name is the name of the staff member.
     * @return "Not found" if staff not found, "Already hired" if staff
     * is already hired, "Not enough money" if not enough money in the
     * account, "Hired" if staff are hired. All messages should include
     * the staff name and state of the project account.
     **/
    @Override
    public String hireStaff(String name) {
        Staff staffToHire = allStaff.get(name);
        String result;

        if (staffToHire == null) {
            result = "Not found: " + name;
        } else if (staffToHire.getState() != StaffState.AVAILABLE) {
            result = "Already hired: " + name;
        } else if (account < staffToHire.getRetainer()) {
            result = "Not enough money to hire " + name + " (Retainer: £" + String.format("%.2f", staffToHire.getRetainer()) + ")";
        } else {
            account -= staffToHire.getRetainer();
            staffToHire.setState(StaffState.WORKING);
            teamStaff.put(name, staffToHire);
            result = "Hired: " + name;
        }
        return result + "\nAccount = £" + String.format("%.2f", account);
    }

    /**
     * Returns true if the staff with the specified name
     * is in the team, false otherwise.
     *
     * @param name is the name of the staff.
     * @return true if the staff with the name is in the team,
     * false otherwise.
     **/
    @Override
    public boolean isInTeam(String name) {
        return teamStaff.containsKey(name);
    }


    /**
     * Returns a String representation of the staff in the project team
     * (including those on leave), or the message "No staff hired".
     *
     * @return a String representation of the staff in the project team.
     **/
    @Override
    public String getTeam() {
        String s = "************ TEAM ********\n";
        if (teamStaff.isEmpty()) {
            s += "No staff hired.";
        } else {
            // Sort team staff by name for consistent display
            List<Staff> sortedTeam = new ArrayList<>(teamStaff.values());
            sortedTeam.sort(Comparator.comparing(Staff::getName));
            for (Staff staff : sortedTeam) {
                s += staff.toString() + "\n";
            }
        }
        return s;
    }


    /**
     * Retrieves the job with the job reference number, or returns "No
     * such job". If job exists, finds a staff member in the team who can
     * do the job. The results of doing a job will be one of the following:
     * "No such Job" - with no further action taken.
     * "Job completed by..." - add the cost of the job to account and include name of staff, staff go "on leave".
     * "Job not completed as no staff available" - deduct job penalty from account.
     * "Job not completed due to staff inexperience" - deduct penalty from the account.
     * If a job is not completed and the project account becomes negative,
     * add "ITProject is overdrawn " to the output.
     *
     * @param jbNo is the reference number of the job.
     * @return a String showing the result of doing the job (as above).
     */
    @Override
    public String doJob(int jbNo) {
        System.out.println("DEBUG: doJob called for " + jbNo + ". allJobs map size: " + allJobs.size() + ", contains " + jbNo + ": " + allJobs.containsKey(jbNo));
        Job jobToDo = allJobs.get(jbNo);
        String outcome = "\nJob No " + jbNo;

        if (jobToDo == null) {
            return outcome + " - No such Job.";
        }

        Staff chosenStaff = null;
        // Find the first available staff member in the team who can do the job
        List<Staff> workingStaff = new ArrayList<>(teamStaff.values());
        workingStaff.sort(Comparator.comparing(Staff::getName)); // Sort by name to get "first" consistently

        for (Staff staff : workingStaff) {
            if (staff.getState() == StaffState.WORKING && staff.canDoJob(jobToDo.getType())) {
                chosenStaff = staff;
                break; // Found the first suitable working staff
            }
        }

        if (chosenStaff == null) {
            account -= jobToDo.getPenalty();
            outcome += " - Job not completed as no staff available.";
        } else if (chosenStaff.getExperience() < jobToDo.getDifficultyLevel()) {
            account -= jobToDo.getPenalty();
            outcome += " - Job not completed due to staff inexperience. (Staff: " + chosenStaff.getName() + " Experience: " + chosenStaff.getExperience() + ", Job Difficulty: " + jobToDo.getDifficultyLevel() + ")";
        } else {
            double jobCost = jobToDo.getHours() * chosenStaff.getHourlyRate();
            account += jobCost;
            chosenStaff.setState(StaffState.ONLEAVE); // Staff goes on leave after completing job
            outcome += String.format(" - Job completed by %s. Cost: £%.2f", chosenStaff.getName(), jobCost);
        }

        outcome += String.format("\nAccount = £%.2f", account);
        if (isOverdrawn()) {
            outcome += " ITProject is overdrawn.";
        }
        return outcome;
    }


    /**
     * Staff rejoin the team after holiday by setting state to "working".
     *
     * @param name - the name of the staff rejoining the team after leave.
     * @return confirmation of return.
     */
    @Override
    public String staffRejoinTeam(String name) {
        Staff staff = teamStaff.get(name);
        if (staff == null) {
            return name + " not in team so can't return from leave.";
        }
        if (staff.getState() == StaffState.ONLEAVE) {
            staff.setState(StaffState.WORKING);
            return name + " has rejoined the team and is now working.";
        } else if (staff.getState() == StaffState.WORKING) {
            return name + " is already working and not on leave.";
        } else { // Should ideally not happen if only 'available' staff are hired
            return name + " is not available for work (current state: " + staff.getState().toString().trim() + ").";
        }
    }

    //****************** private methods for Task 6.1 functionality*******************

    /**
     * Sets up the initial staff members (Installers, Consultants, Planners)
     * and adds them to the allStaff collection, initially in AVAILABLE state.
     */
    private void setupStaff() {
        // Data from Appendix A
        // Planners
        allStaff.put("Amir", new Planner("Amir", 2, "Homebase")); // 300 retainer, 2*15=30 hourly
        allStaff.put("Firat", new Planner("Firat", 6, "Hygena")); // 300 retainer, 6*15=90 hourly
        allStaff.put("Jaga", new Planner("Jaga", 4, "Homebase")); // 300 retainer, 4*15=60 hourly

        // Consultants
        allStaff.put("Bela", new Consultant("Bela", 2, 100, false)); // 100 retainer, 30 hourly
        allStaff.put("Ceri", new Consultant("Ceri", 4, 250, true)); // 250 retainer, 40 hourly
        allStaff.put("Hui", new Consultant("Hui", 8, 450, true)); // 450 retainer, 40 hourly

        // Installers
        allStaff.put("Dana", new Installer("Dana", 2, false)); // 200 retainer, 20 hourly, not trained
        allStaff.put("Eli", new Installer("Eli", 7, true)); // 200 retainer, 20 hourly, trained
        allStaff.put("Gani", new Installer("Gani", 2, true)); // 200 retainer, 20 hourly, trained
    }

    /**
     * Sets up default jobs if no job file is provided (or if testing requires predefined jobs)
     * This method is only used if the constructor without jobfile is used.
     */
    private void setupJobs() {
        // This is typically called only if jobs are NOT read from a file.
        // For this project, jobs are read from "jobs.txt", so this method should ensure they are loaded.
        readJobs("jobs.txt"); // Call readJobs with the default jobs file to ensure jobs are always loaded
    }


    // *************** file write/read  *********************

    /**
     * Writes the Manager object to the specified file using serialization.
     *
     * @param filename name of file to which schedule is written.
     */
    @Override
    public void saveManager(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(this);
            System.out.println("Manager state saved to " + filename);
        } catch (IOException e) {
            System.err.println("Error saving manager state: " + e.getMessage());
        }
    }

    /**
     * Reads the Manager object from specified file using serialization and restores it.
     *
     * @param filename name of file from which schedule is read.
     * @return the whole Manager object, or null if restoration fails.
     */
    @Override
    public Manager restoreManager(String filename) {
        Manager restoredManager = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            restoredManager = (Manager) ois.readObject();
            System.out.println("Manager state restored from " + filename);
        } catch (FileNotFoundException e) {
            System.err.println("Error: File not found - " + filename);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error restoring manager state: " + e.getMessage());
        }
        return restoredManager;
    }

    /**
     * Reads jobs from a text file such as "jobs.txt".
     *
     * @param fname - name of the text file.
     */
    @Override
    public void readJobs(String fname) {
        System.out.println("DEBUG: Entering readJobs method for " + fname);
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(fname))) {
            String line;
            int lineNumber = 0; // For debugging line numbers
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                line = line.trim(); // Trim whitespace from the line
                if (line.isEmpty()) {
                    System.out.println("DEBUG: Skipping empty line " + lineNumber);
                    continue; // Skip empty lines
                }

                System.out.println("DEBUG: Processing line " + lineNumber + ": '" + line + "'");

                String[] parts = line.split(",");
                // Expect 5 parts: Type,Location,Difficulty,Hours,Penalty
                if (parts.length == 5) {
                    try {
                        JobType type = JobType.valueOf(parts[0].trim().toUpperCase()); // Convert string to enum
                        String location = parts[1].trim();
                        int difficulty = Integer.parseInt(parts[2].trim());
                        int hours = Integer.parseInt(parts[3].trim());
                        double penalty = Double.parseDouble(parts[4].trim());

                        // Debug: print parsed values
                        System.out.println(String.format("DEBUG:    Parsed values (line %d): Type=%s, Loc=%s, Diff=%d, Hours=%d, Penalty=%.2f. Assigning Job No: %d",
                                lineNumber, type, location, difficulty, hours, penalty, nextJobNo));

                        allJobs.put(nextJobNo, new Job(nextJobNo, type, location, hours, difficulty, penalty));
                        System.out.println("DEBUG:    Added Job " + nextJobNo + " to allJobs map. Current map size: " + allJobs.size());
                        nextJobNo++; // Increment for the next job
                    } catch (NumberFormatException e) {
                        System.err.println("ERROR: Number format error on line " + lineNumber + " in jobs file " + fname + ": " + e.getMessage() + " Line: '" + line + "'");
                    } catch (IllegalArgumentException e) {
                        System.err.println("ERROR: Invalid job type on line " + lineNumber + " in jobs file " + fname + ": " + e.getMessage() + " Line: '" + line + "'");
                    }
                } else {
                    System.err.println("ERROR: Skipping malformed job line " + lineNumber + " (incorrect number of parts): '" + line + "' (Expected 5 parts, got " + parts.length + ")");
                }
            }
            System.out.println("DEBUG: Jobs loaded from " + fname + ". Final allJobs map size: " + allJobs.size());
        } catch (IOException e) {
            System.err.println("ERROR: Reading jobs from file " + fname + ": " + e.getMessage());
        }
        System.out.println("DEBUG: Exiting readJobs method.");
    }
}