package refdefcwk;

import java.io.Serializable;

/**
 * Represents an Installer staff member in the HISS simulation.
 * Installers can perform Installation tasks. They can also do Maintenance tasks
 * if they are trained to work with electricity.
 *

 */
public class Installer extends Staff implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization

    private boolean trained; // Trained to work with electricity for maintenance tasks

    /**
     * Constructor for the Installer class.
     *
     * @param name       The unique name of the installer.
     * @param experience The experience level of the installer (1-10).
     * @param trained    True if the installer is trained to work with electricity, false otherwise.
     */
    public Installer(String name, int experience, boolean trained) {
        super(name, experience);
        this.trained = trained;
        this.retainer = 200.00; // Fixed retainer for Installers
        this.hourlyRate = 20.00; // Fixed hourly rate for Installers
    }

    /**
     * Checks if the Installer can perform a specific job type.
     * Installers can do INSTALLATION tasks.
     * They can do MAINTENANCE tasks only if trained.
     * They cannot do DESIGN tasks.
     *
     * @param jobType The type of job to check against.
     * @return true if the installer can perform the job, false otherwise.
     */
    @Override
    public boolean canDoJob(JobType jobType) {
        switch (jobType) {
            case INSTALLATION:
                return true;
            case MAINTENANCE:
                return trained; // Only if trained
            case DESIGN:
                return false;
            default:
                return false;
        }
    }

    /**
     * Provides a detailed string representation of the Installer.
     * Includes general staff details and whether they are trained.
     *
     * @return A string containing the installer's details.
     */
    @Override
    public String toString() {
        return super.toString() + String.format(", Trained: %s", trained ? "Yes" : "No");
    }
}