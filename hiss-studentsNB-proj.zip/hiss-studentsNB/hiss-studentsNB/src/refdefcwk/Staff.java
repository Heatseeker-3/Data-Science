package refdefcwk;

import java.io.Serializable;

/**
 * Abstract base class for all staff members in the HISS simulation.
 * It defines common attributes and abstract methods that concrete staff types must implement.
 * Implements Serializable to allow Manager objects to be saved and restored.
 *
 * @author Your Name / SRN
 * @version 2025-06-13
 */
public abstract class Staff implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization

    private String name;
    private int experience; // 1-10
    protected double retainer; // protected to allow subclasses to set if needed (e.g., Consultant)
    protected double hourlyRate; // protected to allow subclasses to set
    private StaffState state;

    /**
     * Constructor for the Staff class.
     *
     * @param name       The unique name of the staff member.
     * @param experience The experience level of the staff member (1-10).
     */
    public Staff(String name, int experience) {
        this.name = name;
        this.experience = experience;
        this.state = StaffState.AVAILABLE; // All staff start as AVAILABLE
    }

    /**
     * Gets the name of the staff member.
     *
     * @return The staff member's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the experience level of the staff member.
     *
     * @return The staff member's experience.
     */
    public int getExperience() {
        return experience;
    }

    /**
     * Gets the retainer fee for the staff member.
     *
     * @return The retainer amount.
     */
    public double getRetainer() {
        return retainer;
    }

    /**
     * Gets the hourly rate of the staff member.
     *
     * @return The hourly rate.
     */
    public double getHourlyRate() {
        return hourlyRate;
    }

    /**
     * Gets the current state of the staff member.
     *
     * @return The current StaffState (AVAILABLE, WORKING, ONLEAVE).
     */
    public StaffState getState() {
        return state;
    }

    /**
     * Sets the state of the staff member.
     *
     * @param newState The new StaffState for the staff member.
     */
    public void setState(StaffState newState) {
        this.state = newState;
    }

    /**
     * Abstract method to check if the staff member can perform a given job type.
     * This must be implemented by concrete staff types.
     *
     * @param jobType The type of job to check against.
     * @return true if the staff can perform the job, false otherwise.
     */
    public abstract boolean canDoJob(JobType jobType);

    /**
     * Provides a detailed string representation of the staff member.
     *
     * @return A string containing the staff member's type, name, experience, retainer, hourly rate, and state.
     */
    @Override
    public String toString() {
        // FIX: Prepend the simple class name (e.g., "Planner", "Consultant", "Installer")
        return String.format("%s: Name: %s, Experience: %d, Retainer: £%.2f, Hourly Rate: £%.2f, State: %s",
                this.getClass().getSimpleName(), name, experience, retainer, hourlyRate, state.toString().trim());
    }
}