package refdefcwk;

import java.io.Serializable;

/**
 * Represents a job or task in the HISS simulation.
 * Each job has a unique number, type, location, estimated hours,
 * difficulty level, and an associated penalty.
 * Implements Serializable to allow Manager objects to be saved and restored.
 *

 */
public class Job implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization

    private int jobNo;
    private JobType type;
    private String location;
    private int hours;
    private int difficultyLevel; // 1-10
    private double penalty;

    /**
     * Constructor for the Job class.
     *
     * @param jobNo          The unique sequential job number.
     * @param type           The type of the job (Design, Installation, Maintenance).
     * @param location       The location where the job is to be performed.
     * @param hours          The estimated number of hours to complete the job.
     * @param difficultyLevel The difficulty level of the job (1-10).
     * @param penalty        The penalty incurred if the job is not completed.
     */
    public Job(int jobNo, JobType type, String location, int hours, int difficultyLevel, double penalty) {
        this.jobNo = jobNo;
        this.type = type;
        this.location = location;
        this.hours = hours;
        this.difficultyLevel = difficultyLevel;
        this.penalty = penalty;
    }

    /**
     * Gets the unique job number.
     *
     * @return The job number.
     */
    public int getJobNo() {
        return jobNo;
    }

    /**
     * Gets the type of the job.
     *
     * @return The JobType (Design, Installation, Maintenance).
     */
    public JobType getType() {
        return type;
    }

    /**
     * Gets the location of the job.
     *
     * @return The job location.
     */
    public String getLocation() {
        return location;
    }

    /**
     * Gets the estimated hours to complete the job.
     *
     * @return The number of hours.
     */
    public int getHours() {
        return hours;
    }

    /**
     * Gets the difficulty level of the job.
     *
     * @return The difficulty level (1-10).
     */
    public int getDifficultyLevel() {
        return difficultyLevel;
    }

    /**
     * Gets the penalty associated with the job if not completed.
     *
     * @return The penalty amount.
     */
    public double getPenalty() {
        return penalty;
    }

    /**
     * Provides a detailed string representation of the job.
     *
     * @return A string containing the job's number, type, location, hours, difficulty, and penalty.
     */
    @Override
    public String toString() {
        return String.format("Job No: %d, Type: %s, Location: %s, Hours: %d, Difficulty: %d, Penalty: £%.2f",
                jobNo, type.toString().trim(), location, hours, difficultyLevel, penalty);
    }
}