package refdefcwk;

import java.io.*;
import java.util.*;

/**
 * provides a command line interface
 *
 * @author A.A.Marczyk
 * @version 2025-06-13 (Updated)
 */
public class ManagerUI {
    private static HISS man1;
    private static Scanner myIn = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        String managerName; // Not strictly needed for Manager constructor, but kept from original

        try {
            System.out.println("Enter manager's name:");
            String mg = myIn.nextLine();
            // Create manager with a default budget and load jobs from "jobs.txt"
            man1 = new Manager(mg, 1000, "jobs.txt");
            choice = 100; // Initialize with a non-zero value to enter loop

            while (choice != 0) {
                choice = getMenuItem();
                if (choice == 1) {
                    System.out.println(man1.toString());
                } else if (choice == 2) {
                    System.out.println(man1.getAllAvailableStaff());
                } else if (choice == 3) {
                    System.out.println("Enter Staff name to hire:");
                    String nme = (myIn.nextLine()).trim();
                    if (!man1.isOverdrawn()) { // Only allow hiring if not overdrawn
                        System.out.println(man1.hireStaff(nme));
                    } else {
                        System.out.println("Project is overdrawn. Cannot hire staff.");
                    }
                } else if (choice == 4) {
                    // *** Student Task: List staff in the team ***
                    System.out.println(man1.getTeam());
                } else if (choice == 5) {
                    System.out.println(man1.getAllJobs());
                } else if (choice == 6) {
                    // *** Student Task: Do a job ***
                    System.out.println("Enter Job number to perform:");
                    try {
                        int jbNo = myIn.nextInt();
                        myIn.nextLine(); // Consume newline
                        System.out.println(man1.doJob(jbNo));
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a number for job number.");
                        myIn.nextLine(); // Consume the invalid input
                    }
                } else if (choice == 7) {
                    System.out.println("Enter Staff name to rejoin team:");
                    String nme = (myIn.nextLine()).trim();
                    if (man1.isInTeam(nme)) { // Check if staff is in the team before trying to rejoin
                        System.out.println(man1.staffRejoinTeam(nme));
                    } else {
                        System.out.println(nme + " is not in your team.");
                    }
                }
                // Task 2.5 (Save/Restore)
                else if (choice == 8) {
                    System.out.println("Enter filename to save manager state:");
                    String filname = (myIn.nextLine()).trim();
                    man1.saveManager(filname);
                } else if (choice == 9) {
                    System.out.println("Enter filename to restore manager state from:");
                    String fname = (myIn.nextLine()).trim();
                    HISS restored = man1.restoreManager(fname);
                    if (restored != null) {
                        man1 = restored; // Update the current manager instance
                        System.out.println("Restored project state:");
                        System.out.println(man1.toString()); // Display restored state
                    } else {
                        System.out.println("Failed to restore manager state.");
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("An I/O error occurred: " + e.getMessage());
        } catch (Exception e) { // Catch any other unexpected exceptions
            System.err.println("An unexpected error occurred: " + e.getMessage());
            e.printStackTrace(); // Print stack trace for debugging
        } finally {
            myIn.close(); // Close the scanner when done
        }
        System.out.println("Thank-you for using HISS!");
    }

    private static int getMenuItem() throws IOException {
        int choice = -1; // Initialize with an invalid choice
        System.out.println("\n--- Main Menu ---");
        System.out.println("0. Quit");
        System.out.println("1. List project information (Manager, Account, Team)");
        System.out.println("2. List staff available for hire");
        System.out.println("3. Hire staff for team");
        System.out.println("4. List staff in the team"); // Completed
        System.out.println("5. List all jobs");
        System.out.println("6. Do a job"); // Completed
        System.out.println("7. Staff rejoin team from leave");
        System.out.println("8. Save game");
        System.out.println("9. Restore game");

        while (choice < 0 || choice > 9) {
            System.out.println("Enter the number of your choice:");
            try {
                choice = myIn.nextInt();
                myIn.nextLine(); // Consume the newline character after reading int
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                myIn.nextLine(); // Consume the invalid input to prevent infinite loop
                choice = -1; // Reset choice to keep loop going
            }
        }
        return choice;
    }
}